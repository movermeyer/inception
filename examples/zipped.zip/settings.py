QUESTIONS = [
    { "kind": "text",
      "name": "name",
      "message": "What's your name"
    },
    { "kind": "text",
      "name": "surname",
      "message": "What's your surname"
    },
    { "kind": "list",
      "name": "size",
      "message": "What size do you need?",
      "choices": ["Jumbo", "Large", "Standard", "Medium", "Small", "Micro"]
    }
]
